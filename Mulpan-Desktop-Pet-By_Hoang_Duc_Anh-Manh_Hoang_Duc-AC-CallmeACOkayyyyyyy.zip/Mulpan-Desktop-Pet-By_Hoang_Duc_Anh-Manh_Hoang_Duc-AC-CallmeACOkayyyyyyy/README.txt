This is an application made by Hoang Duc Anh - Manh Hoang Duc - AC - CallmeACOkayyyyyyy.
***
*Note: No copying are allowed because this is my original product that I spend lots of time making and creating!
***
*Make sure not to rename the application or else you will need to change the CLOSE batch file codes (right click at the batch file >> edit >> look for "taskkill /f /im Mulpan.exe" >> change the "Mulpan.exe" to YOUR_NEW_NAME.exe [make sure to keep the .exe] before changing the name of the app [change the name of the app to the name you type in the batch file, as well.])
 ***
What is interesting about this?
- Mulpan stands on your taskbar and starts doing things randomly.
- Sometimes he dances that makes your whole screen inverted colorfully.
This was fairly annoying to be honest, but it brings back attentions to Mulpan and make this less boring!
***
This was made for Mulpan and Partition (two of the famous Geometry Dash players around the world). I really hope they will see it and make a video about this! Made in a couple of hours! Enjoy!